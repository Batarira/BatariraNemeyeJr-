// BATARIRA NEMEYE Jérémie 21439 GEI 2024-2025
package TP.TP3;

public interface Vehicule {
    public void demarrer();
    public void arreter();
    public int getVitesseMax();
}
